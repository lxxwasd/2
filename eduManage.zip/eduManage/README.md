# ssm-login2
整合SSM，通过Mysql数据库验证登录操作，登录成功跳转成功页面，反之亦然
![项目结构图片](https://github.com/xubingpeng/ssm-login2/blob/master/%E9%A1%B9%E7%9B%AE%E7%BB%93%E6%9E%84.jpg)
