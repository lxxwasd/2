package com.edu.service.impl;

import com.edu.mapper.UserMapper;
import com.edu.pojo.User;
import com.edu.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserServiceImpl implements UserService {

    //业务逻辑层中，一定有数据访问层的对象
    //让Spring容器自动注入Mapper的对象
    @Autowired
   private UserMapper userMapper;

    //根据传入的用户到DB中查询相应用户对象
    public User login(User user){
        return userMapper.login(user);
    }

}
