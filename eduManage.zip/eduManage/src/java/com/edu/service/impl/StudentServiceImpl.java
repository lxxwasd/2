package com.edu.service.impl;

import com.edu.mapper.StudentMapper;
import com.edu.pojo.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class StudentServiceImpl {

    @Autowired
    private StudentMapper studentMapper;


    public Student search(Student student){
        return studentMapper.search(student);
    }

    public int updateStudent(Student student) {
        return studentMapper.updateStudent(student);
    }
}
