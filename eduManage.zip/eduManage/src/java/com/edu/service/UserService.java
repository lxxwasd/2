package com.edu.service;

import com.edu.pojo.User;

public interface UserService {
    public User login(User user);

}
