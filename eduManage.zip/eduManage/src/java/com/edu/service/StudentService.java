package com.edu.service;

import com.edu.pojo.Student;

public interface StudentService {

    public Student search(Student student);
    public int updateStudent(Student student);
}
