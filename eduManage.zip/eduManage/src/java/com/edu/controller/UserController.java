package com.edu.controller;

import com.edu.pojo.User;
import com.edu.service.impl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class UserController {
    @Autowired
    private UserServiceImpl userServiceImpl;
    @RequestMapping(value = {"/login","/log"},method = {RequestMethod.POST,RequestMethod.GET})
    public ModelAndView login (User user){
        ModelAndView modelAndView=new ModelAndView();
        User u= userServiceImpl.login(user);

        if(u!=null){
            modelAndView.addObject("success","登录成功");
            modelAndView.addObject("user",u);
            modelAndView.setViewName("/success.jsp");
        }
        else{
            modelAndView.addObject("error","登录失败");
            modelAndView.setViewName("/error.jsp");
        }
        return modelAndView;
    }
}
