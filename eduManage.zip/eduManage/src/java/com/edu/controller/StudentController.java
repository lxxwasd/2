package com.edu.controller;

import com.edu.pojo.Student;
import com.edu.service.impl.StudentServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class StudentController {

    @Autowired
    private StudentServiceImpl studentServiceImpl;


    @RequestMapping(value = {"/search"},method = {RequestMethod.POST,RequestMethod.GET})
    public ModelAndView search (Student student){

        ModelAndView modelAndView=new ModelAndView();
        //数据库中查找该学生的具体信息
        Student s1= studentServiceImpl.search(student);

        modelAndView.addObject("student",s1);
        modelAndView.setViewName("/search.jsp");

        return modelAndView;
    }


    @RequestMapping(value = {"/modify"},method = {RequestMethod.POST,RequestMethod.GET})
    public ModelAndView modify (Student student){

        ModelAndView modelAndView=new ModelAndView();
        int temp= studentServiceImpl.updateStudent(student);
    if(temp==1){
        modelAndView.addObject("success","修改成功");
        modelAndView.setViewName("/success.jsp");
        return modelAndView;}
    else{
        modelAndView.addObject("error","修改失败");
        modelAndView.setViewName("/error.jsp");
        return modelAndView;
    }
    }
}
