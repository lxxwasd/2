package com.edu.pojo;

public class Student {
    private String sid;
    private String school;

    private String ethnicGroup;

    private String politicalLandscape;
    private String sname;
    private String sex;
    private int grade;
    private int sclass;
    private String hometown;
    private String address;
    private String phone;
    private String parentName;
    private String parentPhone;
    private int schoolYear;

    private String degree;

    public Student(String sid, String school, String ethnicGroup, String politicalLandscape, String sname, String sex, int grade, int sclass, String hometown, String address, String phone, String parentName, String parentphone, int schoolYear, String degree) {
        this.sid = sid;
        this.school = school;
        this.ethnicGroup = ethnicGroup;
        this.politicalLandscape = politicalLandscape;
        this.sname = sname;
        this.sex = sex;
        this.grade = grade;
        this.sclass = sclass;
        this.hometown = hometown;
        this.address = address;
        this.phone = phone;
        this.parentName = parentName;
        this.parentPhone = parentphone;
        this.schoolYear = schoolYear;
        this.degree = degree;
    }

    public Student(String sid) {
        this.sid = sid;
    }

    public Student() {}

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getEthnicGroup() {
        return ethnicGroup;
    }

    public void setEthnicGroup(String ethnicGroup) {
        this.ethnicGroup = ethnicGroup;
    }

    public String getPoliticalLandscape() {
        return politicalLandscape;
    }

    public void setPoliticalLandscape(String politicalLandscape) {
        this.politicalLandscape = politicalLandscape;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public int getSclass() {
        return sclass;
    }

    public void setSclass(int sclass) {
        this.sclass = sclass;
    }

    public String getHometown() {
        return hometown;
    }

    public void setHometown(String hometown) {
        this.hometown = hometown;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public String getParentphone() {
        return parentPhone;
    }

    public void setParentphone(String parentphone) {
        this.parentPhone = parentphone;
    }

    public int getSchoolYear() {
        return schoolYear;
    }

    public void setSchoolYear(int schoolYear) {
        this.schoolYear = schoolYear;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }
}
