package com.edu.mapper;

import com.edu.pojo.User;

public interface UserMapper {
    public User login(User user);

}
