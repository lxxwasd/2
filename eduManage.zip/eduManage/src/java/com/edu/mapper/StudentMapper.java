package com.edu.mapper;

import com.edu.pojo.Student;
public interface StudentMapper {

    public  Student search(Student student);

    int updateStudent(Student student);
}
